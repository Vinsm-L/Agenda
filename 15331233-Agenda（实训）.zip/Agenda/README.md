## PUBLIC CODES for SYSU SS TRNG 2016 - Agenda
+ **WATCH** this repo so that github would notify you when we update codes.
+ You just have to implement the given interfaces with **ANY way you like**.
+ Call TA if there is any question

### File sturctures
+ src : header files for Agenda Project

